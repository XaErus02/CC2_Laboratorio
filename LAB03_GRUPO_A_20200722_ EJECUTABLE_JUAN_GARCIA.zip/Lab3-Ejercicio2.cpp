//Estudiante: Juan Diego Garcia Macedo
#include <iostream>

using namespace std;

void bisiesto(int a);

int main(){
    int a;
    cout<<"Ingrese año: ";cin>>a;
    bisiesto(a);

    return 0;
}

void bisiesto(int a){
    int aux;
    aux=a%4;
    if (aux==0){
        cout<<"\nEl año "<<a<<" es bisiesto";
    }
    else{
        cout<<"\nEl año "<<a<<" no es bisiesto";
    }
}