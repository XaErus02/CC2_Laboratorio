//Estudiante: Juan Diego Garcia Macedo
#include <iostream>
#include <conio.h>
using namespace std;
void numPrimos(int a);
int main(){
    int x;
    cout<<"Límite: ";
    cin>>x;
    if (x>=2){
        numPrimos(x);
    }
    else{
        cout<<"Este límite no esta permitido"<<endl;
    }
    return 0;
}
void numPrimos(int x){
    int cont;
    for (int i=2; i<=x; i++){
            for (int a=1;a<=i; a++){
                if (i%a==0){
                    cont++;
                }
            }
                if (cont==2){
                    cout<<i<<" ";
                }
            cont=0;
        }
}
