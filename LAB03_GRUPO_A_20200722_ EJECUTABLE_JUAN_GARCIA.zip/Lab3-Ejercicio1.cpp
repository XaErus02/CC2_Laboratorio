//Estudiante: Juan Diego Garcia Macedo
#include <iostream>

using namespace std;

void potencia(int a, int b);


int main(){
    int a,b;

    cout<<"Numero base: ";
    cin>>a;
    cout<<"Exponencia: ";
    cin>>b;
    potencia(a,b);
    return 0;
}


void potencia(int a, int b){
    int aux=1;
    for (int i=1; i <b+1; i++){
        aux=aux*a;
    }
    cout<<"La potencia de "<<a<<" a la "<<b<<" da como resultado "<<aux;
}